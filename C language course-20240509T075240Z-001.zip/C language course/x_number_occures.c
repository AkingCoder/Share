#include <stdio.h>

int main() {
    int array[] = {1, 2, 3, 4, 2, 5, 2, 6, 2, 7}; // Replace this with your array
    int n = 10; // Calculate the size of the array
    int x = 2; // The number you want to find

    int count = 0; // Initialize a count to zero
    int a = array[0];
    // Iterate through the array and count occurrences of 'x'
    for (int i = 1; i < n; i++) {
        if (array[i] == array[a]) {
            count++;
            a = array[i]
        }
    }

    // Print the count
    printf("The number %d occurs %d times in the array.\n", x, count);

    return 0;
}
