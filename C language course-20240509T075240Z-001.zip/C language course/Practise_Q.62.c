#include<stdio.h>
int main(){
    FILE *fptr;
    fptr = fopen("Student.txt","w");
    char name[100];
    int age;
    float per;
    printf("Enter Name = ");
    scanf("%s",name);
    printf("Enter Age = ");
    scanf("%d",&age);
    printf("Enter Percentage = ");
    scanf("%f",&per);
    fprintf(fptr,"Student Name\tAge\t\tPercentage\t\n\n");
    fprintf(fptr,"\t%s\t",name);
    fprintf(fptr,"\t%d\t",age);
    fprintf(fptr,"\t%f\t",per);
    
    fclose(fptr);
    return 0;
}