#include <stdio.h>

int main() {
    int array[] = {10, 5, 45, 23, 67, 1000, 89, 12}; // Replace this with your array
    int n = sizeof(array) / sizeof(array[0]); // Calculate the size of the array

    // Initialize the maximum value to the first element of the array
    int max = array[0];

    // Iterate through the array to find the maximum value
    for (int i = 1; i < n; i++) {
        if (array[i] > max) {
            max = array[i];
        }
    }

    // Print the maximum value
    printf("The greatest number in the array is: %d\n", max);

    return 0;
}
