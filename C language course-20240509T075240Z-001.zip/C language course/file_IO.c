#include<stdio.h>
int main(){
  FILE *fptr;
  fptr = fopen("test.txt","r");
  int ch;
  while(ch!=5){
    fscanf(fptr, "%d",&ch);
    printf("%d\n",ch);
  }
  fclose(fptr);
  return 0;    
}