#include<stdio.h>
struct student{
    char name[100];
    int roll;
    float per;
};
int main(){
    // Short hand
  struct student s1={"Anand",15,93};
  printf("Student name = %s\n",s1.name); 


  //   using pointer
  struct student *ptr=&s1;
  printf("Roll no. = %d\n",(*ptr).roll);

  //   another method using pointer
  printf("Percentage = %f\n", ptr->per);


  return 0;
}