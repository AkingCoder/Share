#include<stdio.h>
#include<string.h>
struct student {
    char name[100];
    int roll;
    float per;
    };
int main(){
    struct student s1;

    strcpy(s1.name, "Anand");
    s1.roll = 15;
    s1.per = 89.70;

    printf("Name of student= %s\n", s1.name);
    printf("Roll no.= %d\n", s1.roll);
    printf("Percentage= %f\n\n", s1.per);



    struct student s2;

    strcpy(s2.name, "Saurav");
    s2.roll = 60;
    s2.per = 69.30;

    printf("Name of student= %s\n", s2.name);
    printf("Roll no.= %d\n", s2.roll);
    printf("Percentage= %f\n\n", s2.per);



    return 0;
}