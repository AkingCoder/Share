#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	// int a[5];
	char test[5][5] = {"10","20","30","40","50"};
	// for(int i = 0;i < 5;i++ ){
	// 	if(test[i][0] > test[i][1]){
	// 		a[i] = atoi(test[i][0]);
	// 	}	
	// 	else{
	// 		a[i] = atoi(test[i][1]);
	// 	}
	// }
	// printf("%d",a);
	printf("%d",strcat(test[0]))

	return 0;
}