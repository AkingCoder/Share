#include<stdio.h>
#include<string.h>
struct student {
    char name[100];
    int roll;
    float per;
    };
int main(){
    struct student BCA[100];
    BCA[0].roll=13;
    BCA[0].per=89;
    strcpy(BCA[0].name,"Anand");
    printf("Name= %s\n",BCA[0].name);
    printf("Roll no.= %d\n",BCA[0].roll);
    printf("Percentage= %f\n",BCA[0].per);
    return 0;
}