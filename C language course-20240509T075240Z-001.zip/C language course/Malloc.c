#include<stdio.h>
#include<stdlib.h>
int main(){
    float *price;
    int n;
    printf("Enter value you want to store: ");
    scanf("%d",&n);
    price=(float *)calloc(n , sizeof(float));
    // price[0]=908;
    // price[1]=734;
    // price[2]=213;
    // price[3]=563;
    // price[4]=243;
    for (int i = 0; i < n; i++)
    {
        printf("%f\n",price[i]);
    }
    free(price);
    price=(float *)calloc(2 , sizeof(float));
    for (int i = 0; i < 2; i++)
    {
        printf("%f\n",price[i]);
    }
    return 0;
}