#include<stdio.h>
void scan_array(int arr[],int n);
int main(){
    int ind;
    printf("Enter index: ");
    scanf("%d",&ind);
    int a[ind];
    scan_array(a,ind);
    return 0;
}
void scan_array(int arr[],int n){
    for(int i=0;i<=n;i++){
        printf("Enter number%d: ",i);
        scanf("%d",&arr[i]); 
    }
    for(int i=n;i>=0;--i){
        printf("%d",arr[i]);
    }
    
}