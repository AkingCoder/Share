#include <stdio.h>

int main(){
  int a;
  printf("Enter marks: ");
  scanf("%d",&a);
  if(30<=a && a < 70 ){
    printf("Grade is B");
  }
  else if (a<30){
    printf("Grade is C");
  }
  else if(70<=a && a < 90 ){
    printf("Grade is A");
  }
  else if(90<=a && a <= 100 ){
    printf("Grade is A+");
  }
  else{
    printf("Invalid marks");
  }
  return 0;
}