#include<stdio.h>



int main() {
	float radius;
	printf("Enter radius: ");
	scanf("%f",&radius);
  printf("Area of Circle: %f",radius*radius);
	return 0;

}