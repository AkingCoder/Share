#include <stdio.h>

int main(){
  float a,b,c;
  printf("Enter number: ");
  scanf("%f",&a);
  printf("Enter number: ");
  scanf("%f",&b);
  printf("Enter number: ");
  scanf("%f",&c);
  printf("Average = %f",a+b+c/3);
  return 0;
}