#include<stdio.h>
int main(){
    char s[100] = "Anand Khandelwal";
    for (int i = 0; s[i] != '\0'; i++)
    {
        if (s[i]!=' '){
        printf("%c",s[i]);
        }
    
    } 
}