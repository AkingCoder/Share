#include<stdio.h>
#include<string.h>
int main(){
    char pas[100];
    char salt[] = "123";
    char mix[200];
    printf("Enter Your password : ");
    scanf("%s",&pas);
    strcpy(mix,pas);
    strcat(mix,salt);
    printf("%s",mix);


    return 0;
    
}