#include<stdio.h>
void print_string(char arr[]);
int main(){
    char FirstName[]="Anand";
    char LastName[]="khandelwal";
    print_string(FirstName);
    printf("%s",LastName);
    return 0;    
}
void print_string(char arr[]){
    for(int i=0;arr[i] != '\0';i++){
        printf("%c\n",arr[i]);
    }
    printf("\n");
}