#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct Node
{   
    int data;
    struct Node *next;
};
struct Node *DeleteFirst(struct Node * first){
    struct Node * ptr = first;
    first = first->next;
    free(ptr);
    return first;
}
struct Node *DeleteAtIndex(struct Node * first,int index){
    
    struct Node * p = first;
    struct Node * q = first->next;
    if (index == 0)
    {   
        first = DeleteFirst(first) ;
    }

    for (int i = 0; i < index-1; i++)
    {
        p = p->next;
        q = q->next;
    }
    p->next = q->next;
    free(q);
    return first;
}

struct Node *DeleteAtValue(struct Node * first,int data){
    
    struct Node * p = first;
    struct Node * q = first->next;
    if (p->data == data)
    {   
        return DeleteFirst(first);
    }


    while (q->data != data && q->next != NULL)
    {
        p = p->next;
        q = q->next;
    }
    if (q->data == data)
    {
        p->next = q->next;
        free(q);
    }
    
    return first;
}

struct Node *DeleteLast(struct Node * first){
    
    struct Node * p = first;
    struct Node * q = first->next;

    while (q->next != NULL)
    {
        p = p->next;
        q = q->next;
    }

    p->next = q->next;
    free(q);
    
    return first;
}
void traversal(struct Node *ptr){
    while (ptr != NULL)
    {
        printf("Element = %d\n",ptr->data);
        ptr = ptr->next;
    }
    
}

int main(){
    struct Node *first;
    struct Node *second;
    struct Node *third;
    struct Node *fourth;
    struct Node *five;

    first = (struct Node *)malloc(sizeof(struct Node));
    second = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));
    five = (struct Node *)malloc(sizeof(struct Node));


    first->data=10;
    first->next=second;

    second->data=20;
    second->next=third;

    third->data=30;
    third->next=fourth;

    fourth->data=40;
    fourth->next=five;

    five->data=50;
    five->next=NULL;

    first = DeleteLast(first) ;
    traversal(first);
    return 0;


}
