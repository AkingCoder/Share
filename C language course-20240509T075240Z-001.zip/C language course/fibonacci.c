#include<stdio.h>
int main(){
    int n,f,s,i;
    printf("Enter number: ");
    scanf("%d",&n);
    f=0;s=1;
    for(i=0;i<=n;i++){
        printf("%d",f);
        if(n==0){
            return 0;
        }
        else if(n==0){
            return 0;
        }
        int next = f+s;
        f = s;
        s = next;
    }
    return 0;
}
