#include<stdio.h>
int main(){
    int a;
    printf("Enter number: ");
    scanf("%d",&a);
    if(a>0){
        printf("It is natural number");
    }
    else if(a<=0){
        printf("It is not a natural number");
    }
    else{
        printf("Error");
    }
    return 0;
}
