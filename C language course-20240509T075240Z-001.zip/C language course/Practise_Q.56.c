#include<stdio.h>
typedef struct address{
    int house_no;
    int block;
    char city[100];
    char state[100];
}ad;
int main(){
    ad add[5]={
        {25,12,"jaipur","Rajasthan"},
        {15,11,"Alwar","Rajasthan"},
        {20,15,"Ajmer","Rajasthan"},
        {22,5,"Kota","Rajasthan"},
        {29,2,"jaipur","Rajasthan"}
        };

    for (int i = 1; i<=4; i++)
    {
        printf("House no.= %d\n",add[i].house_no);
        printf("Block no.= %d\n",add[i].block);
        printf("City = %s\n",add[i].city);
        printf("State = %s\n",add[i].state);

    }
    
    return 0;
}