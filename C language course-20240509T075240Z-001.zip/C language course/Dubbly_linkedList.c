#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct Node
{   
    struct Node *prevNode;
    int data;
    struct Node *next;
};

void traversal(struct Node *ptr){
    while (ptr != NULL)
    {
        printf("Element = %d\n",ptr->data);
        ptr = ptr->next;
    }
    
}

int main(){
    struct Node *first;
    struct Node *second;
    struct Node *third;
    struct Node *fourth;
    struct Node *five;

    first = (struct Node *)malloc(sizeof(struct Node));
    second = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));
    five = (struct Node *)malloc(sizeof(struct Node));

    first->prevNode=NULL;
    first->data=10;
    first->next=second;

    second->prevNode = first;
    second->data=20;
    second->next=third;

    third->prevNode = second;
    third->data=30;
    third->next=fourth;

    fourth->prevNode = third;
    fourth->data=40;
    fourth->next=five;

    five->prevNode = fourth;
    five->data=50;
    five->next=NULL;

    traversal(first);

    return 0;


}
