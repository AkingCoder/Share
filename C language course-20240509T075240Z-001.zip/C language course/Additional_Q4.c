#include<string.h>
#include <stdio.h>

void highest(char ch[], int n);

int main() {
    int n;
    printf("Enter the value of n: ");
    scanf("%d", &n);

    char ch[] = "abSF"; // You can use strlen(ch) to determine the length of the string.
    highest(ch, n);

    return 0;
}

void highest(char ch[], int n) {
    int length = strlen(ch);

    if (n <= 0 || n > length) {
        printf("Invalid value of n.\n");
        return;
    }

    for (int i = 0; i < n; i++) {
        char maxChar = ch[0];
        int maxIndex = 0;

        for (int j = 1; j < length; j++) {
            if (ch[j] > maxChar) {
                maxChar = ch[j];
                maxIndex = j;
            }
        }

        if (i == n - 1) {
            printf("The %d-th highest character is: %c\n", n, maxChar);
        }

        // Set the character at maxIndex to a very low value to avoid it being considered again.
        ch[maxIndex] = '\0';
    }
}