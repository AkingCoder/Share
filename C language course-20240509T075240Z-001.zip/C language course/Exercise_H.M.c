#include<stdio.h>
int main(){
    FILE *fptr;
    fptr=fopen("SUM.txt","ra");
    int n;
    while(n!=EOF){
        fscanf(fptr,"%d",&n);
    }
    if(n=='7'){
        fprintf(fptr,"%d",5);
    }
    fclose(fptr);
    return 0;
}