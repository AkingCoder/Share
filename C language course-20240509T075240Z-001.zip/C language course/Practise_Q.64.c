#include<stdio.h>
int main(){
    FILE *fptr;
    fptr=fopen("SUM.txt","r");
    int n;
    int m;
    fscanf(fptr,"%d%d",&n,&m);
    printf("%d\n",n);
    printf("%d",m);
    fclose(fptr);
    fptr= fopen("SUM.txt","w");
    fprintf(fptr,"Sum = %d",n+m);
    fclose(fptr);
    return 0;
}
