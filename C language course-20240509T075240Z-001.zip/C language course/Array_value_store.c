#include<stdio.h>
void value_insert(int array[],int n);
int main(){
    int ind;
    printf("How many numbers do you want to store : ");
    scanf("%d",&ind);
    int array[ind];
    value_insert(array,ind);
    for (int i = 0; i < ind; i++)
    {
        printf("%d\t",array[i]);
    }
    
    return 0;
}
void value_insert(int array[],int n){
    for(int i=0;i<n;i++){
        printf("Enter number %d = ",i);
        scanf("%d",&array[i]);
    }
}