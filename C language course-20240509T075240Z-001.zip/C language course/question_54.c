#include<stdio.h>
void check_word(char a[],char b);
int main(){
    char a[100];
    char b = 'a';
    printf("Enter any string: ");
    scanf("%c",&a);
    printf("Enter character that you want to check: ");
    check_word(a,b);
    return 0;
}
void check_word(char a[],char b){
    for (int i = 0; a[i]!='\0'; i++)
    {
        if (a[i]==b){
            printf("Yes");
            return;
        }
    }
    printf("No");
}