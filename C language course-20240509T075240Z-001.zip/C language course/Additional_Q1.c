#include <stdio.h>
#include <string.h>
void convert(char str[]);
int main() {
  char inp[100];
  scanf("%s", inp);
  convert(inp);
  printf("%s", inp);
}
void convert(char str[]) {
  for (int i = 0; str[i] != '\0'; i++) {
    switch (str[i]) {
    case 'a':
    case 'e':
    case 'i':
    case 'o':
    case 'u':
      str[i] = toupper(str[i]);
      break;
    }
  }
}
    