#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
struct Node * InsertAtIndex(struct Node *first,int data,int index){
    struct Node *ptr = (struct Node *)malloc(sizeof(struct Node));
    struct Node *p = first;
    int  i = 1;
    while (i != index)
    {
        p = p->next;
        i++;
    }
    ptr->data = data;
    ptr->next = p->next;     
    p->next = ptr;
    return first;

}

void traversal(struct Node *ptr)
{
    struct Node *p = ptr;

    do
    {
        printf("Element = %d\n", ptr->data);
        ptr = ptr->next;
    } while (ptr->next != p->next);
}


int main()
{
    struct Node *first;
    struct Node *second;
    struct Node *third;
    struct Node *fourth;
    struct Node *five;

    first = (struct Node *)malloc(sizeof(struct Node));
    second = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));
    five = (struct Node *)malloc(sizeof(struct Node));

    first->data = 10;
    first->next = second;

    second->data = 20;
    second->next = third;

    third->data = 30;
    third->next = fourth;

    fourth->data = 40;
    fourth->next = five;

    five->data = 50;
    five->next = first;
    
    first = InsertAtIndex(first,60,0);

    traversal(first);

    return 0;
}
