#include <stdio.h>
#include <string.h>
#include <ctype.h>
void convert_letters(char ch[]);
int main(){
    char ch[100]="aNAND";
    convert_letters(ch);
    return 0;
}
void convert_letters(char ch[]){
    for (int i = 0; ch[i]!='\0'; i++)
    {
        if (ch[i]>='A' && ch[i]<='Z')
        {
            ch[i] = tolower(ch[i]);
            
        }
        else if (ch[i]>='a' && ch[i]<='z')
        {
             ch[i] = toupper(ch[i]);

        }
    }
    printf("%s",ch);
    
}