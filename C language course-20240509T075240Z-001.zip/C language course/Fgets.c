#include<stdio.h>
#include<string.h>
int main(){
    char a[50] = "pop";
    char b[] = "corn";

    // printf("Enter name : ");
    // fgets(a,50,stdin);
    // int s = 0;
    // for (int i = 0; a[i] != '\0'; i++)
    // {

    //     if (a[i] != '\0')
    //     {
    //         s++;
    //     }
        
    // }
    // printf("%d",s-1);
    // int len = strlen(a);
    // printf("%d",len - 1);
    // strcopy(a,b);
    // printf("%s",a);
    // printf("%s",strcat(a,b));
    printf("%d",strcmp(a,b));
    // printf("%s",b);
    return 0;
}