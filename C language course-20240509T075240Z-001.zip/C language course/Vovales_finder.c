#include<stdio.h>
int vovels_finder(char a[]);
int main(){
    char a[100];
    printf("Enter any string to find vovels: ");
    scanf("%c",&a);
    printf("Number of vovels: %d",vovels_finder(a));
    return 0;
}
int vovels_finder(char a[]){
    int count=0;
    for (int i = 0; a[i]!='\0'; i++)
    {
        if (a[i]=='a'){
            count++;
        }
        else if (a[i]=='e'){
            count++;
        }
        else if (a[i]=='i'){
            count++;
        }
        else if (a[i]=='o'){
            count++;
        }
        else if (a[i]=='u'){
            count++;
        }
        
    }
    return count;
    
}
