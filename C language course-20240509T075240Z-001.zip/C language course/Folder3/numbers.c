#include<stdio.h>
int main(){
    int i;
    scanf("%d",i); 
    for(int i;i<=11;i=+1){
        printf("%d",i);
    }
    return 0;
}