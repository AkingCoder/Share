#include<stdio.h>
#include<string.h>
typedef struct details{
    int roll;
    char name[100];
    int age;
    char state[100];
    float per;
}det;
void store_data(int num);
int main(){
    int num;
    printf("Enter Number of Students = ");
    scanf("%d",&num);
    num =num-1;
    store_data(num);
    
    return 0;
}
void store_data(int num){
    for (int i = 0; i<=num; i++)
    {
        printf("STUDENT ID NO = %d\n",i+1);  
        det id[i];
        printf(" Enter Roll no = ");
        scanf("%d",&id[i].roll);  
        printf(" Enter Name = ");
        scanf("%s",id[i].name);  
        printf(" Enter Age = ");
        scanf("%d",&id[i].age);  
        printf(" Enter State = ");
        scanf("%s",id[i].state);  
        printf(" Enter Previous year Percentage = ");
        scanf("%f",&id[i].per);

    }

    int index;
    printf("Enter Student ID to get details = ");
    scanf("%d",&index);
    index=index-1;
    det id[index];
    printf("Roll No = %d\n",id[index].roll);
    printf("Name = %s\n",id[index].name);
    printf("Age = %d\n",id[index].age);
    printf("State = %s\n",id[index].state);
    printf("Previous year percentage = %f\n",id[index].per);
   
}